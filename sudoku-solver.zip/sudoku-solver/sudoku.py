import sys
import copy
from hashSet import HashSet

        
def rule1(group):
  # RULE 1 - You have to look for duplicate sets (i.e. set([1,6])). If you 
  # have same number of duplicate sets in a group (row, column, square) as 
  # the cardinality of the duplicate set size, then they must each get one 
  # value from the duplicate set. In this case the values of the duplicate 
  # set may be removed from all the other sets in the group. 
  
  changed = False

  # here we go through all the elements of the group which are sorted from
  # smallest to largest cardinality
  for index in range(9):
    # get the cardinality of the set
    cardinality = len(group[index])
    count = 0
    if cardinality >= 2:
      for other_index in range(index+1,9):
        if group[index].issuperset(group[other_index]):
          # they must be equal because card(group[i]) <= card(group[j])
          count=count+1  
          
    # if there are card sets with card elements then the other sets can't 
    # have any of these values in them since these sets will have to 
    # each have one of the card values. 
    if count+1 == cardinality:
      # go through the sets and for each set different from the given set
      # take out all the elements that are in given set
      for other_index in range(9):
        current_set = group[other_index]
        if not group[index].issuperset(current_set):
          current_set_size= len(current_set)
          current_set.difference_update(group[index])
          if len(current_set) < current_set_size:
            changed = True

  return changed
  
def rule2(group):

  # RULE 2 - Reduce Set size by throwing away elements that appear in other sets
  # in the group
  #print("before rule2 : ")
  #printGroup(group)
  changed = False

  # pick an element of the group
  for index in range(9):
    current_set = group[index]
    current_set_size = len(current_set)
    # for all the other elements of the group
    for other_index in range(9):
      if index != other_index:
        # remove the elements that appear in other elements
        # of the group. These can be satisfied by other
        # elements of the group
        current_set = current_set.difference(group[other_index])
    # When you are done, if there is one value left then it can only 
    # be satisfied by this cell. This is a most constrained rule.
    # If we end up with 0 elements, we didn't know enough yet to
    # constrain this choice. If we didn't improve the situation at all,
    # let's continue looking at other elements in the row. 
    if 1 == len(current_set) < current_set_size:
      group[index].clear()
      group[index].update(current_set)
      changed = True 
  #print("after rule2 : ");
  #printGroup(group)
  return changed
 
def getColumn(matrix, colIndex):
    col = []
    for rowIndex in range(9):
        col.append(matrix[rowIndex][colIndex])
    return col

def getSquare(matrix, rowIndex, colIndex):
    square = []

    for i in range(rowIndex, rowIndex+3):
        for j in range(colIndex, colIndex+3):
            square.append(matrix[i][j])
            
    return square

def getGroups(matrix):
    groups = []

    # get rows
    for i in range(9):
        groups.append(list(matrix[i]))

    # get columns
    for i in range(9):
        groups.append(getColumn(matrix, i))

    # get squares
    # left to right, top to bottom
    for i in range(0, 9, 3):
        for j in range(0, 9, 3):
            groups.append(getSquare(matrix, i, j))

    return groups

def cardinality(x):
    return len(x)

def reduceGroup(group):
    changed = False

    group.sort(key=cardinality)

    changed = rule2(group)
    changed = rule1(group)

    return changed
    
def reduceGroups(groups):
    changed = False

    for group in groups:
        if reduceGroup(group):
            changed = True

    return changed


def reduce(matrix):
    changed = True
    groups = getGroups(matrix)

    while changed:
        changed = reduceGroups(groups)


def printMatrix(matrix):
    for i in range(9):
        for j in range(9):
            if len(matrix[i][j]) != 1:
                sys.stdout.write("x ")
            else:
                for k in matrix[i][j]:
                    sys.stdout.write(str(k) + " ")
        sys.stdout.write("\n")


def solutionViable(matrix):
    for i in range(9):
        for j in range(9):
            if (len(matrix[i][j])) == 0:
                return False
    return True


def union(group):
    result = HashSet([])

    for s in group:
        result.update(s)

    return result

def solutionOK(matrix):
    for i in range(9):
        for j in range(9):
            if (len(matrix[i][j])) != 1:
                return False

    for theRow in matrix:
        if (len(union(theRow))) != 9:
            return False

    for j in range(9):
        theColumn = getColumn(matrix, j)
        if len(union(theColumn)) != 9:
            return False

    for i in range(0, 9, 3):
        for j in range(0, 9, 3):
            theSquare = getSquare(matrix, i, j)
            if len(union(theSquare)) != 9:
                return False

    return True

        

def solve(matrix):

    reduce(matrix)

    if not solutionViable(matrix):
        return None

    if solutionOK(matrix):
        return matrix

    print("Searching...")

    # apply DFS + backtracking
    for i in range(9):
        for j in range(9):
            if (len(matrix[i][j])) > 1:
                for k in matrix[i][j]:
                    mcopy = copy.deepcopy(matrix)
                    mcopy[i][j] = HashSet([k])

                    result = solve(mcopy)

                    if result != None:
                        return result

    return None

def main():
    file = open(sys.argv[1], "r")
    matrix = []

    for line in file:
        lst = line.split()
        row = []

        for val in lst:
            if val == 'x':
                s = HashSet(range(1,10))
            else:
                s = HashSet([eval(val)])
            row.append(s)
        
        matrix.append(row)

    print("Solving this puzzle: ")
    printMatrix(matrix)

    print("Begin solving...")
    matrix = solve(matrix)

    if matrix == None:
        print()
        print("No soltion found...")
        return
    
    print()
    print("Solution: ")
    printMatrix(matrix)

main()
        
        
        
